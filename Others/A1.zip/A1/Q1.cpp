//khushdeep kaur
//student id number:100394454
//course:info 1112 s51
#include <iostream>
int main() {
int speed = 20;
int time=10;
int distance=speed*time;
std::cout<<distance;
return 0;
}
