//student id:100394454
//name:khushdeep kaur
#include <iostream>
int main() {
float force = 172.5;
float area = 27.5;
float pressure = force/area;
std::cout<<pressure;
return 0;
}
